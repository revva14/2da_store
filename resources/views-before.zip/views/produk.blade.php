@extends('layouts.app')

@section('title', '2DA Store — Detail Produk')

@push('styles')
<style>
  /* ---------- PRODUCT DETAIL ---------- */
  .product-section{ padding: 30px 0 100px; }

  .product-grid{
    display:grid;
    grid-template-columns: 1fr 1fr;
    gap: 64px;
    align-items:start;
  }

  /* gallery */
  .gallery-main{
    border-radius: var(--radius-lg);
    overflow:hidden;
    aspect-ratio: 1/0.95;
    background:#eee;
    box-shadow: 0 20px 40px -18px rgba(60,30,10,.3);
  }
  .gallery-main img{ width:100%; height:100%; object-fit:cover; }

  /* info */
  .product-label{
    display:inline-block;
    font-size:12.5px;
    font-weight:700;
    letter-spacing:.08em;
    text-transform:uppercase;
    color: var(--orange-dark);
    margin-bottom:14px;
  }

  .product-info h1{
    font-family: var(--font-display);
    font-weight:800;
    font-size:38px;
    line-height:1.15;
    color: var(--ink);
    margin-bottom:16px;
  }

  .product-info .price{
    display:block;
    text-align:left;
    font-family: var(--font-display);
    font-weight:700;
    font-size:24px;
    color: var(--orange-dark);
    margin-bottom:28px;
  }

  .product-info .desc p{
    font-size:15.5px;
    color: var(--ink-soft);
    margin-bottom:18px;
    line-height:1.75;
  }

  .buy-row{
    display:flex;
    gap:16px;
    margin-top:30px;
  }

  .qty-stepper{
    display:flex;
    align-items:center;
    background: var(--white);
    border-radius: var(--radius-pill);
    padding: 6px;
    flex:none;
  }
  .qty-stepper button{
    width:38px; height:38px;
    border-radius:50%;
    background: transparent;
    font-size:18px;
    font-weight:600;
    color: var(--ink);
    display:flex; align-items:center; justify-content:center;
    transition: background .2s ease;
  }
  .qty-stepper button:hover{ background: var(--cream-soft); }
  .qty-stepper span{
    width:44px;
    text-align:center;
    font-weight:700;
    font-size:15px;
  }

  .btn-buy{
    flex:1;
    background: var(--orange);
    color:#fff;
    font-weight:700;
    font-size:15px;
    border-radius: var(--radius-pill);
    box-shadow: 0 12px 24px -10px rgba(217,123,41,.6);
    transition: background .2s ease, transform .1s ease;
  }
  .btn-buy:hover{ background: var(--orange-dark); }
  .btn-buy:active{ transform: scale(0.98); }

  /* accordion */
  .accordion{
    margin-top:34px;
    border-top:1px solid rgba(0,0,0,.08);
  }
  .accordion-item{ border-bottom:1px solid rgba(0,0,0,.08); }
  .accordion-toggle{
    width:100%;
    background:none;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding: 20px 2px;
    font-family: var(--font-display);
    font-weight:700;
    font-size:15px;
    color: var(--ink);
  }
  .accordion-icon{
    font-size:20px;
    font-weight:400;
    color: var(--orange-dark);
    transition: transform .25s ease;
    line-height:1;
  }
  .accordion-toggle.open .accordion-icon{ transform: rotate(45deg); }

  .accordion-content{
    max-height:0;
    overflow:hidden;
    transition: max-height .3s ease;
  }
  .accordion-content ul{
    padding: 0 2px 20px;
  }
  .accordion-content li{
    font-size:14.5px;
    color: var(--ink-soft);
    padding: 6px 0 6px 22px;
    position:relative;
  }
  .accordion-content li::before{
    content:"";
    position:absolute;
    left:0; top:14px;
    width:6px; height:6px;
    border-radius:50%;
    background: var(--orange);
  }

  /* ---------- RELATED ---------- */
  .related{ padding: 20px 0 100px; }
  .related h2{
    font-family: var(--font-display);
    font-weight:800;
    font-size:26px;
    margin-bottom:28px;
  }
  .related h2 .accent{ color: var(--orange); }

  .related-grid{
    display:grid;
    grid-template-columns: repeat(4, 1fr);
    gap:24px;
  }
  .related-card{
    background: var(--white);
    border-radius: var(--radius-md);
    overflow:hidden;
    box-shadow: 0 8px 20px -14px rgba(60,30,10,.3);
    transition: transform .18s ease, box-shadow .18s ease;
  }
  .related-card:hover{ transform: translateY(-4px); box-shadow: 0 14px 26px -14px rgba(60,30,10,.35); }
  .related-media{ aspect-ratio: 1/0.85; overflow:hidden; background:#eee; }
  .related-media img{ width:100%; height:100%; object-fit:cover; }
  .related-body{ padding:16px 18px 20px; }
  .related-body h4{ font-family: var(--font-display); font-weight:700; font-size:14.5px; margin-bottom:6px; }
  .related-body .price{ font-size:13.5px; font-weight:700; color: var(--orange-dark); }

  /* ---------- TOAST ---------- */
  .toast{
    position:fixed; bottom:30px; left:50%;
    transform: translateX(-50%) translateY(20px);
    background: var(--brown-dark);
    color:#fff;
    padding: 14px 26px;
    border-radius: var(--radius-pill);
    font-size:14px; font-weight:500;
    opacity:0; pointer-events:none;
    transition: opacity .25s ease, transform .25s ease;
    z-index:999;
    box-shadow: 0 12px 26px -8px rgba(0,0,0,.4);
  }
  .toast.show{ opacity:1; transform: translateX(-50%) translateY(0); }

  /* ---------- RESPONSIVE (khusus halaman ini) ---------- */
  @media (max-width: 980px){
    .product-grid{ grid-template-columns:1fr; gap:36px; }
    .related-grid{ grid-template-columns: repeat(2,1fr); }
  }
  @media (max-width: 560px){
    .product-info h1{ font-size:28px; }
    .buy-row{ flex-direction:column; }
    .related-grid{ grid-template-columns:1fr; }
  }
</style>
@endpush

@section('content')

  <section class="product-section">
    <div class="container product-grid">

      <!-- GALLERY -->
      <div class="reveal">
        <div class="gallery-main">
          <img id="mainImage" src="" alt="">
        </div>
      </div>

      <!-- INFO -->
      <div class="product-info reveal">
        <span class="product-label" id="productLabel">Menu Favorit</span>
        <h1 id="productName">Nama Produk</h1>
        <div class="price" id="productPrice">Rp 0</div>

        <div class="desc" id="productDesc"></div>

        <div class="buy-row">
          <div class="qty-stepper">
            <button type="button" id="qtyMinus">−</button>
            <span id="qtyValue">1</span>
            <button type="button" id="qtyPlus">+</button>
          </div>
          <button class="btn btn-buy" id="addToCartBtn">Tambah ke Keranjang</button>
        </div>

        <div class="accordion">
          <div class="accordion-item">
            <button class="accordion-toggle" id="highlightsToggle">
              <span>Keunggulan Produk</span>
              <span class="accordion-icon">+</span>
            </button>
            <div class="accordion-content" id="highlightsContent">
              <ul id="highlightsList"></ul>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>

  <section class="related reveal">
    <div class="container">
      <h2>Produk <span class="accent">Lainnya</span></h2>
      <div class="related-grid" id="relatedGrid"></div>
    </div>
  </section>

  <div class="toast" id="toast">Item ditambahkan ke keranjang</div>

@endsection

@push('scripts')
<script>
  // ---------- DATA PRODUK (terhubung dengan menu lewat ?id=) ----------
  const PRODUCTS = {
    corndog: {
      name: "Corndog Mini Mozzarella",
      price: 5000,
      label: "Terlaris",
      image: "{{ asset('images/corndog.jpg') }}",
      desc: [
        "Corndog Mini Mozarella kami menghadirkan sensasi gigitan renyah di luar dan lumer di dalam. Balutan tepung crispy yang digoreng garing membungkus keju mozarella premium yang meleleh sempurna di setiap suapan, disiram saus sambal dan mayones khas yang bikin nagih.",
        "Dibuat fresh setiap hari dengan bahan pilihan, corndog mini ini pas banget jadi camilan sore, teman nongkrong, atau bekal ngemil kapan aja. Praktis disantap langsung dari tusuknya, cocok buat semua usia — dari anak-anak sampai dewasa."
      ],
      ingredients: ["Digoreng garing setiap kali pesanan masuk", "Keju mozzarella premium lumer sempurna", "Porsi mini pas untuk sekali gigitan", "Praktis disantap langsung dari tusuknya"]
    },
    cireng: {
      name: "Cireng Isi Mini",
      price: 5000,
      image: "{{ asset('images/cireng.jpg') }}",
      desc: [
        "Cireng Isi Mini punya tekstur kenyal khas cireng di luar dengan isian gurih yang melimpah di dalam — mulai dari ayam suwir pedas sampai keju yang lumer, siap memanjakan lidah di setiap gigitan. Digoreng garing sampai warnanya kuning keemasan, disajikan hangat dengan cocolan sambal favoritmu.",
        "Ukuran mini yang pas buat ngemil santai, cocok dinikmati rame-rame bareng teman atau keluarga. Jajanan sejuta umat ini selalu jadi andalan buat menemani waktu senggangmu."
      ],
      ingredients: ["Kenyal di luar, isian melimpah di dalam", "Digoreng garing hingga keemasan", "Disajikan hangat dengan cocolan sambal", "Ukuran mini, pas dinikmati rame-rame"]
    },
    coklat: {
      name: "Pop Ice Coklat",
      price: 5000,
      image: "{{ asset('images/coklat.jpg') }}",
      desc: [
        "Pop Ice jadi minuman segar andalan buat menemani harimu, hadir dengan berbagai varian rasa manis dan menyegarkan yang siap melepas dahaga. Diseduh dan disajikan dingin dengan tekstur creamy yang bikin nagih setiap tegukan.",
        "Cocok diminum siang hari saat cuaca terik atau sebagai teman santai sore-sore. Kesegarannya bikin mood langsung membaik!"
      ],
      ingredients: ["Rasa coklat creamy dan menyegarkan", "Disajikan dingin, pas untuk cuaca panas", "Porsi pas, tidak bikin eneg", "Cepat saji, langsung siap diminum"]
    },
    maryam: {
      name: "Roti Maryam Mini",
      price: 5000,
      image: "{{ asset('images/maryam.jpg') }}",
      desc: [
        "Roti Maryam Mini punya lapisan yang berlapis-lapis, renyah di luar dan lembut di dalam, dengan aroma mentega yang menggoda. Disajikan hangat bersama taburan gula atau siraman kuah kari/coklat sesuai selera, menciptakan perpaduan rasa manis gurih yang bikin ketagihan.",
        "Ukuran mininya pas buat ngemil ringan atau dinikmati beramai-ramai. Enak disantap kapan aja — pagi buat sarapan, sore buat teman ngeteh, atau malam buat cemilan santai."
      ],
      ingredients: ["Berlapis-lapis, renyah di luar lembut di dalam", "Aroma mentega yang menggoda", "Bisa dinikmati manis maupun gurih", "Cocok untuk sarapan, ngeteh, atau cemilan malam"]
    },
    tahu: {
      name: "Tahu Crispy",
      price: 5000,
      image: "{{ asset('images/tahu.jpg') }}",
      desc: [
        "Tahu Crispy kami digoreng dengan balutan tepung renyah yang garing sempurna, membungkus tahu lembut nan gurih di dalamnya. Perpaduan tekstur crunchy di luar dan lembut di dalam ini bikin susah berhenti ngemil.",
        "Disajikan dengan sambal kecap atau saus sambal sesuai selera, tahu crispy ini pas jadi camilan sore atau pelengkap makan siangmu. Praktis, mengenyangkan, dan pastinya bikin nagih."
      ],
      ingredients: ["Renyah di luar, lembut gurih di dalam", "Bumbu meresap sempurna ke dalam tahu", "Cocok jadi camilan atau pelengkap makan", "Porsi mengenyangkan, harga terjangkau"]
    },
    tempura: {
      name: "Tempura Jontor",
      price: 5000,
      image: "{{ asset('images/tempura.jpg') }}",
      desc: [
        "Tempura Jontor hadir dengan level pedas yang bikin nagih — gurihnya tempura ikan yang kenyal berpadu dengan saus pedas nampol yang bikin bibir jontor tapi tetap ketagihan buat nambah lagi. Cocok buat kamu pecinta pedas sejati!",
        "Disajikan hangat dengan tusukan praktis, tempura jontor ini jadi teman ngemil paling asik saat kumpul bareng teman. Siap-siap keringetan tapi susah berhenti!"
      ],
      ingredients: ["Level pedas nampol yang bikin nagih", "Tekstur kenyal khas tempura ikan", "Disajikan hangat dengan tusukan praktis", "Favorit para pecinta pedas sejati"]
    }
  };

  function formatRupiah(n){
    return "Rp " + n.toLocaleString("id-ID");
  }

  // Ambil id produk dari URL, fallback ke corndog kalau tidak ada / tidak ditemukan
  const params = new URLSearchParams(window.location.search);
  const requestedId = params.get('id');
  const productId = (requestedId && PRODUCTS[requestedId]) ? requestedId : 'corndog';
  const product = PRODUCTS[productId];

  // Render info utama
  document.title = `2DA Store — ${product.name}`;
  document.getElementById('productLabel').textContent = product.label;
  document.getElementById('productName').textContent = product.name;
  document.getElementById('productPrice').textContent = formatRupiah(product.price);
  document.getElementById('mainImage').src = product.image;
  document.getElementById('mainImage').alt = product.name;

  const descWrap = document.getElementById('productDesc');
  product.desc.forEach(paragraf => {
    const p = document.createElement('p');
    p.textContent = paragraf;
    descWrap.appendChild(p);
  });

  // Keunggulan produk
  const highlightsList = document.getElementById('highlightsList');
  product.ingredients.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    highlightsList.appendChild(li);
  });

  // Produk lainnya (semua kecuali yang sedang dibuka)
  const relatedGrid = document.getElementById('relatedGrid');
  Object.entries(PRODUCTS)
    .filter(([id]) => id !== productId)
    .slice(0, 4)
    .forEach(([id, p]) => {
      const a = document.createElement('a');
      a.href = `/produk?id=${id}`;
      a.className = 'related-card';
      a.innerHTML = `
        <div class="related-media"><img src="${p.image}" alt="${p.name}"></div>
        <div class="related-body">
          <h4>${p.name}</h4>
          <span class="price">${formatRupiah(p.price)}</span>
        </div>`;
      relatedGrid.appendChild(a);
    });

  // ---------- Quantity stepper ----------
  let qty = 1;
  const qtyValue = document.getElementById('qtyValue');
  document.getElementById('qtyMinus').addEventListener('click', () => {
    if (qty > 1) { qty--; qtyValue.textContent = qty; }
  });
  document.getElementById('qtyPlus').addEventListener('click', () => {
    qty++; qtyValue.textContent = qty;
  });

  // ---------- Tambah ke keranjang ----------
  const toast = document.getElementById('toast');
  document.getElementById('addToCartBtn').addEventListener('click', () => {
    toast.textContent = `${qty}x ${product.name} ditambahkan ke keranjang`;
    toast.classList.add('show');
    clearTimeout(window._toastTimer);
    window._toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
  });

  // ---------- Accordion Keunggulan Produk ----------
  const toggleBtn = document.getElementById('highlightsToggle');
  const content = document.getElementById('highlightsContent');
  toggleBtn.addEventListener('click', () => {
    const isOpen = toggleBtn.classList.toggle('open');
    content.style.maxHeight = isOpen ? content.scrollHeight + 'px' : 0;
  });
</script>
@endpush