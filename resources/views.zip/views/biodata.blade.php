@extends('layouts.applogin')

@section('title', 'Biodata Diri — 2DA Store')

@push('styles')
<style>
  /* ---------- ACCOUNT PAGE ---------- */
  .account-page{
    padding: 48px 0 90px;
    position:relative;
    overflow:hidden;
  }
  .account-page::before{
    content:"";
    position:absolute;
    top:-120px; left:-160px;
    width:520px; height:520px;
    background: radial-gradient(circle, var(--peach) 0%, transparent 70%);
    opacity:.6;
    pointer-events:none;
    z-index:0;
  }
  .account-page .container{ position:relative; z-index:1; }

  .account-grid{
    display:grid;
    grid-template-columns: 320px 1fr;
    gap:28px;
    align-items:start;
  }

  /* ---------- PROFILE CARD ---------- */
  .profile-card{
    background: var(--white);
    border-radius: 10px;
    padding: 34px 26px 26px;
    text-align:center;
    box-shadow: 0 14px 30px -18px rgba(60,30,10,.22);
    margin-bottom:20px;
  }
  .profile-avatar{
    width:96px; height:96px;
    margin:0 auto 16px;
    border-radius:50%;
    overflow:hidden;
    border:4px solid var(--cream-soft);
    box-shadow: 0 8px 18px -8px rgba(60,30,10,.35);
  }
  .profile-avatar img{ width:100%; height:100%; object-fit:cover; }

  .profile-name{
    font-family: var(--font-display);
    font-weight:800;
    font-size:17px;
    color: var(--ink);
    margin-bottom:4px;
  }
  .profile-email{
    font-size:12px;
    color: var(--ink-soft);
    margin-bottom:14px;
  }

  .profile-badge{
    display:inline-flex;
    align-items:center;
    gap:6px;
    background:#e8f3de;
    color:#4f7a35;
    font-size:11px;
    font-weight:600;
    padding:6px 14px;
    border-radius: var(--radius-pill);
    margin-bottom:22px;
  }
  .profile-badge::before{
    content:"";
    width:7px; height:7px;
    border-radius:50%;
    background:#5f9a3b;
    flex:none;
  }

  .profile-stats{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:10px;
    padding-top:18px;
    border-top:1px solid rgba(122,59,18,.1);
  }
  .stat-box{
    background: var(--cream-soft);
    border-radius: 10px;
    padding:12px 12px;
    text-align:left;
  }
  .stat-label{
    display:block;
    font-size:9px;
    letter-spacing:.04em;
    text-transform:uppercase;
    color: var(--ink-soft);
    margin-bottom:4px;
  }
  .stat-value{
    font-family: var(--font-display);
    font-weight:700;
    font-size:14px;
    color: var(--ink);
  }
  .stat-value.accent{ color: var(--orange-dark); }

  /* ---------- ACCOUNT MENU ---------- */
  .account-menu{
    background: var(--white);
    border-radius: 10px;
    box-shadow: 0 14px 30px -18px rgba(60,30,10,.22);
    overflow:hidden;
  }
  .account-menu-item{
    display:flex;
    align-items:center;
    gap:12px;
    padding:16px 20px;
    font-size:13px;
    font-weight:600;
    color: var(--ink);
    border-bottom:1px solid rgba(122,59,18,.07);
    transition: background .2s ease, color .2s ease;
  }
  .account-menu-item:last-child{ border-bottom:none; }
  .account-menu-item svg{ width:18px; height:18px; flex:none; }
  .account-menu-item .menu-arrow{ margin-left:auto; opacity:.55; width:16px; height:16px; }
  .account-menu-item.active{ background: var(--orange); color:#fff; }
  .account-menu-item:not(.active):hover{ background: var(--cream-soft); }
  .account-menu-item.logout{ color:#c0392b; }

  /* ---------- MAIN COLUMN ---------- */
  .account-main{
    display:flex;
    flex-direction:column;
    gap:24px;
  }

  .order-card, .info-card{
    background: var(--white);
    border-radius: 10px;
    padding: 30px 32px;
    box-shadow: 0 14px 30px -18px rgba(60,30,10,.22);
  }

  .order-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    flex-wrap:wrap;
    gap:12px;
    padding-bottom:20px;
    border-bottom:1px solid rgba(122,59,18,.08);
    margin-bottom:26px;
  }
  .order-head h2{
    display:flex;
    align-items:center;
    gap:10px;
    font-family: var(--font-display);
    font-weight:800;
    font-size:17px;
    color: var(--ink);
  }
  .order-head h2::before{
    content:"";
    width:9px; height:9px;
    border-radius:50%;
    background:#5f9a3b;
    flex:none;
  }
  .order-status-badge{
    background: var(--cream-soft);
    color: var(--brown-dark);
    font-size:11.5px;
    font-weight:600;
    padding:8px 16px;
    border-radius: var(--radius-pill);
    white-space:nowrap;
  }

  .order-summary-row{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:20px;
    flex-wrap:wrap;
    background: var(--cream-soft);
    border-radius: 10px;
    padding:20px 24px;
    margin-bottom:34px;
  }
  .order-summary-row .label{
    display:block;
    font-size:10px;
    letter-spacing:.05em;
    text-transform:uppercase;
    color: var(--ink-soft);
    margin-bottom:6px;
  }
  .order-summary-row .value{
    font-family: var(--font-display);
    font-weight:700;
    font-size:15px;
    color: var(--ink);
  }
  .order-summary-row .total{ text-align:right; }
  .order-summary-row .total .value{ font-size:19px; color: var(--orange-dark); }
  .order-summary-row .verified{
    display:block;
    font-size:11px;
    font-weight:600;
    color:#4f7a35;
    margin-top:4px;
  }

  /* ---------- STEPPER ---------- */
  .order-stepper{
    display:flex;
    justify-content:space-between;
    margin-bottom:30px;
    padding:0 6px;
  }
  .order-stepper .step{
    display:flex;
    flex-direction:column;
    align-items:center;
    gap:8px;
    position:relative;
    flex:1;
  }
  .order-stepper .connector{
    position:absolute;
    top:20px; left:50%;
    width:100%; height:2px;
    background:#e6d6c8;
    z-index:0;
  }
  .order-stepper .connector.done{ background: var(--orange); }
  .order-stepper .step:last-child .connector{ display:none; }

  .order-stepper .step-icon{
    width:40px; height:40px;
    border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    background: var(--orange);
    color:#fff;
    position:relative;
    z-index:1;
  }
  .order-stepper .step-icon img{
    width:18px; height:18px;
    object-fit:contain;
    filter: brightness(0) invert(1);
  }
  .order-stepper .step.current .step-icon{ background: var(--brown-dark); }
  .order-stepper .step.upcoming .step-icon{
    background:#fff;
    border:2px solid #e6d6c8;
    color:#c9b6a4;
  }

  .order-stepper .step-label{ font-size:12px; font-weight:700; color: var(--ink); }
  .order-stepper .step-time{ font-size:10.5px; color: var(--ink-soft); }
  .order-stepper .step.current .step-label,
  .order-stepper .step.current .step-time{ color: var(--orange-dark); }
  .order-stepper .step.upcoming .step-label,
  .order-stepper .step.upcoming .step-time{ color:#b7a596; }

  .order-driver{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:16px;
    flex-wrap:wrap;
  }
  .order-driver p{ font-size:12.5px; color: var(--ink-soft); }
  .order-driver p strong{ color: var(--ink); }

  .btn-outline-sm{
    display:inline-flex;
    align-items:center;
    gap:6px;
    background: var(--white);
    border:1.5px solid #e6d6c8;
    color: var(--ink);
    font-size:12px;
    font-weight:600;
    padding:10px 18px;
    border-radius: var(--radius-pill);
    white-space:nowrap;
    transition: border-color .2s ease, background .2s ease;
  }
  .btn-outline-sm:hover{ border-color: var(--brown); background: var(--cream-soft); }

  /* ---------- INFO CARD ---------- */
  .info-head{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:16px;
    margin-bottom:28px;
  }
  .info-head h2{
    font-family: var(--font-display);
    font-weight:800;
    font-size:17px;
    color: var(--ink);
    margin-bottom:6px;
  }
  .info-head p{
    font-size:12.5px;
    color: var(--ink-soft);
    max-width:520px;
  }

  .info-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:16px;
  }
  .info-field{
    background: var(--cream-soft);
    border-radius: 10px;
    padding:16px 18px;
    position:relative;
  }
  .info-field .field-label{
    display:block;
    font-size:9.5px;
    letter-spacing:.05em;
    text-transform:uppercase;
    color: var(--ink-soft);
    margin-bottom:6px;
  }
  .info-field .field-value{
    font-family: var(--font-display);
    font-weight:700;
    font-size:13.5px;
    color: var(--ink);
    line-height:1.4;
  }
  .field-verified{
    position:absolute;
    top:14px; right:16px;
    background:#e8f3de;
    color:#4f7a35;
    font-size:9.5px;
    font-weight:700;
    padding:4px 10px;
    border-radius: var(--radius-pill);
  }

  /* ---------- RESPONSIVE ---------- */
  @media (max-width: 980px){
    .account-grid{ grid-template-columns:1fr; }
    .info-grid{ grid-template-columns:1fr; }
  }
  @media (max-width: 560px){
    .order-card, .info-card{ padding:24px 20px; }
    .order-stepper{ flex-wrap:wrap; row-gap:24px; }
    .order-stepper .step{ flex:0 0 50%; }
    .order-stepper .connector{ display:none; }
    .order-summary-row .total{ text-align:left; }
  }
</style>
@endpush

@section('content')

  <section class="account-page reveal">
    <div class="container">
      <div class="account-grid">

        <!-- SIDEBAR -->
        <aside>
          <div class="profile-card">
            <div class="profile-avatar">
              <img src="{{ asset('images/profil-reva.jpg') }}" alt="Foto profil Reva Aulia A.">
            </div>
            <h2 class="profile-name">Reva Aulia A.</h2>
            <p class="profile-email">revanjai@email.com</p>
            <span class="profile-badge">Bergabung sejak Februari 2023</span>

            <div class="profile-stats">
              <div class="stat-box">
                <span class="stat-label">Total Pesanan</span>
                <span class="stat-value">38 Menu</span>
              </div>
              <div class="stat-box">
                <span class="stat-label">Pengeluaran</span>
                <span class="stat-value accent">Rp 145rb</span>
              </div>
            </div>
          </div>

          <nav class="account-menu">
            <a href="/biodata" class="account-menu-item active">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              Biodata Diri
              <svg class="menu-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
            </a>
            <a href="/alamat" class="account-menu-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              Daftar Alamat
            </a>
            <a href="/riwayat" class="account-menu-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="15" y2="17"/></svg>
              Riwayat &amp; Invoice
              <svg class="menu-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
            </a>
            <a href="/pengaturan" class="account-menu-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              Pengaturan Akun
              <svg class="menu-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
            </a>
            <a href="/logout" class="account-menu-item logout">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
              Keluar dari Akun
            </a>
          </nav>
        </aside>

        <!-- MAIN -->
        <div class="account-main">

          <!-- PESANAN SEDANG BERLANGSUNG -->
          <div class="order-card">
            <div class="order-head">
              <h2>Pesanan Sedang Berlangsung</h2>
              <span class="order-status-badge">Dalam Pengantaran Kurir (1.2 km)</span>
            </div>

            <div class="order-summary-row">
              <div>
                <span class="label">ID Pesanan Resmi</span>
                <span class="value">#2DA-89211</span>
              </div>
              <div class="total">
                <span class="label">Total Transaksi</span>
                <span class="value">Rp 25.000</span>
                <span class="verified">QRIS Lunas Terverifikasi</span>
              </div>
            </div>

            <div class="order-stepper">
              <div class="step done">
                <div class="connector done"></div>
                <div class="step-icon">
                  <img src="{{ asset('images/check.png') }}" alt="Diterima">
                </div>
                <span class="step-label">Diterima</span>
                <span class="step-time">11:20 WIB</span>
              </div>
              <div class="step done">
                <div class="connector done"></div>
                <div class="step-icon">
                  <img src="{{ asset('images/frying-pan.png') }}" alt="Dimasak">
                </div>
                <span class="step-label">Dimasak</span>
                <span class="step-time">11:28 WIB</span>
              </div>
              <div class="step current">
                <div class="connector"></div>
                <div class="step-icon">
                  <img src="{{ asset('images/motorbike.png') }}" alt="Diantar Kurir">
                </div>
                <span class="step-label">Diantar Kurir</span>
                <span class="step-time">Tiba dlm 8 mnt</span>
              </div>
              <div class="step upcoming">
                <div class="step-icon">
                  <img src="{{ asset('images/location.png') }}" alt="Tiba di Alamat">
                </div>
                <span class="step-label">Tiba di Alamat</span>
                <span class="step-time">Estimasi 11:45</span>
              </div>
            </div>

            <div class="order-driver">
              <p><strong>Driver:</strong> Kang Rahmat (Honda Vario)<br>Sedang menuju Tebet Barat Dalam VI</p>
              <a href="/akun/riwayat" class="btn-outline-sm">Detail Pesanan</a>
            </div>
          </div>

          <!-- INFORMASI PRIBADI & KONTAK -->
          <div class="info-card">
            <div class="info-head">
              <div>
                <h2>Informasi Pribadi &amp; Kontak</h2>
                <p>Data identitas resmi akun untuk keperluan verifikasi pengantaran dan benefit loyalitas.</p>
              </div>
              <button type="button" class="btn-outline-sm" id="editBiodataBtn">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4z"/></svg>
                Edit
              </button>
            </div>

            <div class="info-grid">
              <div class="info-field">
                <span class="field-label">Nama Lengkap</span>
                <span class="field-value">Reva Aulia A.</span>
              </div>
              <div class="info-field">
                <span class="field-label">Nomor WhatsApp / Seluler</span>
                <span class="field-value">+62 831-2965-6565</span>
                <span class="field-verified">Terverifikasi</span>
              </div>
              <div class="info-field">
                <span class="field-label">Alamat Email</span>
                <span class="field-value">revanjai@email.com</span>
                <span class="field-verified">Terverifikasi</span>
              </div>
              <div class="info-field">
                <span class="field-label">Tanggal Lahir</span>
                <span class="field-value">14 Agustus 2000</span>
              </div>
              <div class="info-field">
                <span class="field-label">Jenis Kelamin</span>
                <span class="field-value">Perempuan</span>
              </div>
              <div class="info-field">
                <span class="field-label">Preferensi Default Pengantaran</span>
                <span class="field-value">Taruh di meja resepsionis / depan pagar jika tak ada orang</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>

@endsection

@push('scripts')
<script>
  // Tombol "Edit" biodata — arahkan ke halaman/mode edit sesuai kebutuhan nanti
  document.getElementById('editBiodataBtn').addEventListener('click', function(){
    window.location.href = '/akun/biodata/edit';
  });
</script>
@endpush