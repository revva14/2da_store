@extends('layouts.applogin')

@section('title', 'Riwayat & Invoice — 2DA Store')

@push('styles')
<style>
  /* ---------- ACCOUNT PAGE (sama seperti biodata) ---------- */
  .account-page{
    padding: 48px 0 90px;
    position:relative;
    overflow:hidden;
  }
  .account-page::before{
    content:"";
    position:absolute;
    top:-120px; left:-160px;
    width:520px; height:520px;
    background: radial-gradient(circle, var(--peach) 0%, transparent 70%);
    opacity:.6;
    pointer-events:none;
    z-index:0;
  }
  .account-page .container{ position:relative; z-index:1; }

  .account-grid{
    display:grid;
    grid-template-columns: 320px 1fr;
    gap:28px;
    align-items:start;
  }

  /* ---------- PROFILE CARD ---------- */
  .profile-card{
    background: var(--white);
    border-radius: 10px;
    padding: 34px 26px 26px;
    text-align:center;
    box-shadow: 0 14px 30px -18px rgba(60,30,10,.22);
    margin-bottom:20px;
  }
  .profile-avatar{
    width:96px; height:96px;
    margin:0 auto 16px;
    border-radius:50%;
    overflow:hidden;
    border:4px solid var(--cream-soft);
    box-shadow: 0 8px 18px -8px rgba(60,30,10,.35);
  }
  .profile-avatar img{ width:100%; height:100%; object-fit:cover; }

  .profile-name{
    font-family: var(--font-display);
    font-weight:800;
    font-size:17px;
    color: var(--ink);
    margin-bottom:4px;
  }
  .profile-email{
    font-size:12px;
    color: var(--ink-soft);
    margin-bottom:14px;
  }

  .profile-badge{
    display:inline-flex;
    align-items:center;
    gap:6px;
    background:#e8f3de;
    color:#4f7a35;
    font-size:11px;
    font-weight:600;
    padding:6px 14px;
    border-radius: var(--radius-pill);
    margin-bottom:22px;
  }
  .profile-badge::before{
    content:"";
    width:7px; height:7px;
    border-radius:50%;
    background:#5f9a3b;
    flex:none;
  }

  .profile-stats{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:10px;
    padding-top:18px;
    border-top:1px solid rgba(122,59,18,.1);
  }
  .stat-box{
    background: var(--cream-soft);
    border-radius: 10px;
    padding:12px 12px;
    text-align:left;
  }
  .stat-label{
    display:block;
    font-size:9px;
    letter-spacing:.04em;
    text-transform:uppercase;
    color: var(--ink-soft);
    margin-bottom:4px;
  }
  .stat-value{
    font-family: var(--font-display);
    font-weight:700;
    font-size:14px;
    color: var(--ink);
  }
  .stat-value.accent{ color: var(--orange-dark); }

  /* ---------- ACCOUNT MENU ---------- */
  .account-menu{
    background: var(--white);
    border-radius: 10px;
    box-shadow: 0 14px 30px -18px rgba(60,30,10,.22);
    overflow:hidden;
  }
  .account-menu-item{
    display:flex;
    align-items:center;
    gap:12px;
    padding:16px 20px;
    font-size:13px;
    font-weight:600;
    color: var(--ink);
    border-bottom:1px solid rgba(122,59,18,.07);
    transition: background .2s ease, color .2s ease;
  }
  .account-menu-item:last-child{ border-bottom:none; }
  .account-menu-item svg{ width:18px; height:18px; flex:none; }
  .account-menu-item .menu-arrow{ margin-left:auto; opacity:.55; width:16px; height:16px; }
  .account-menu-item.active{ background: var(--orange); color:#fff; }
  .account-menu-item:not(.active):hover{ background: var(--cream-soft); }
  .account-menu-item.logout{ color:#c0392b; }

  /* ---------- MAIN COLUMN ---------- */
  .account-main{
    display:flex;
    flex-direction:column;
    gap:24px;
  }

  .btn-outline-sm{
    display:inline-flex;
    align-items:center;
    gap:6px;
    background: var(--white);
    border:1.5px solid #e6d6c8;
    color: var(--ink);
    font-size:12px;
    font-weight:600;
    padding:10px 18px;
    border-radius: var(--radius-pill);
    white-space:nowrap;
    transition: border-color .2s ease, background .2s ease;
  }
  .btn-outline-sm:hover{ border-color: var(--brown); background: var(--cream-soft); }

  .btn-primary-sm{
    display:inline-flex;
    align-items:center;
    gap:8px;
    background: var(--orange);
    color:#fff;
    font-size:13px;
    font-weight:700;
    padding:12px 22px;
    border-radius: var(--radius-pill);
    white-space:nowrap;
    transition: background .2s ease;
  }
  .btn-primary-sm:hover{ background: var(--orange-dark); }

  .btn-soft-sm{
    display:inline-flex;
    align-items:center;
    gap:6px;
    background:#fdebd9;
    color: var(--orange-dark);
    font-size:12px;
    font-weight:700;
    padding:10px 18px;
    border-radius: var(--radius-pill);
    white-space:nowrap;
    transition: background .2s ease;
  }
  .btn-soft-sm:hover{ background:#fbdfc0; }

  .link-review{
    display:inline-flex;
    align-items:center;
    gap:6px;
    font-size:12.5px;
    font-weight:700;
    color: var(--orange-dark);
  }
  .link-review svg{ width:15px; height:15px; fill: var(--orange-dark); }

  /* ---------- BILLING SUMMARY CARD ---------- */
  .billing-card{
    background: var(--white);
    border-radius: 10px;
    padding: 30px 32px;
    box-shadow: 0 14px 30px -18px rgba(60,30,10,.22);
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:24px;
    flex-wrap:wrap;
  }
  .billing-card h1{
    font-family: var(--font-display);
    font-weight:800;
    font-size:20px;
    color: var(--ink);
    margin-bottom:8px;
  }
  .billing-card p{
    font-size:12.5px;
    color: var(--ink-soft);
    max-width:440px;
    margin-bottom:18px;
  }
  .billing-total-box{
    display:inline-block;
    background: var(--cream-soft);
    border-radius: 10px;
    padding:14px 20px;
  }
  .billing-total-box .label{
    display:block;
    font-size:9.5px;
    letter-spacing:.05em;
    text-transform:uppercase;
    color: var(--ink-soft);
    margin-bottom:4px;
  }
  .billing-total-box .value{
    font-family: var(--font-display);
    font-weight:700;
    font-size:16px;
    color: var(--ink);
  }
  .billing-cta{ text-align:right; }
  .billing-cta .btn-primary-sm{ padding:13px 26px; font-size:13.5px; }
  .billing-cta .hint{
    font-size:11px;
    color: var(--ink-soft);
    margin-top:8px;
  }

  /* ---------- FILTER & SEARCH BAR ---------- */
  .filter-bar{
    background: var(--white);
    border-radius: 10px;
    box-shadow: 0 14px 30px -18px rgba(60,30,10,.22);
    padding:16px 18px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:16px;
    flex-wrap:wrap;
  }
  .filter-tabs{
    display:flex;
    flex-wrap:wrap;
    gap:8px;
  }
  .filter-tab{
    background: var(--cream-soft);
    color: var(--ink);
    font-size:12.5px;
    font-weight:600;
    padding:9px 16px;
    border-radius: var(--radius-pill);
    border:none;
    cursor:pointer;
    transition: background .2s ease, color .2s ease;
  }
  .filter-tab:hover{ background:#f0e4d6; }
  .filter-tab.active{ background: var(--orange); color:#fff; }

  .filter-search{
    display:flex;
    align-items:center;
    gap:10px;
    flex:1;
    justify-content:flex-end;
    min-width:220px;
  }
  .search-box{
    position:relative;
    width:100%;
    max-width:260px;
  }
  .search-box svg{
    position:absolute;
    left:14px; top:50%;
    transform:translateY(-50%);
    width:15px; height:15px;
    color:#b7a596;
  }
  .search-box input{
    width:100%;
    background: var(--cream-soft);
    border:1px solid rgba(122,59,18,.08);
    border-radius: var(--radius-pill);
    padding:10px 16px 10px 38px;
    font-size:12.5px;
    color: var(--ink);
  }
  .search-box input::placeholder{ color:#b7a596; }
  .search-box input:focus{ outline:2px solid rgba(217,119,55,.25); }

  .icon-btn{
    width:38px; height:38px;
    display:flex; align-items:center; justify-content:center;
    background: var(--cream-soft);
    border:1px solid rgba(122,59,18,.08);
    border-radius: var(--radius-pill);
    color: var(--ink);
    flex:none;
    transition: background .2s ease;
  }
  .icon-btn:hover{ background:#f0e4d6; }
  .icon-btn svg{ width:16px; height:16px; }

  /* ---------- RIWAYAT (ORDER HISTORY) CARDS ---------- */
  .riwayat-card{
    background: var(--white);
    border-radius: 10px;
    padding: 28px 30px;
    box-shadow: 0 14px 30px -18px rgba(60,30,10,.22);
  }
  .riwayat-card.highlight{
    box-shadow: 0 0 0 2px rgba(217,119,55,.35), 0 14px 30px -18px rgba(60,30,10,.22);
  }

  .riwayat-top{
    display:flex;
    align-items:flex-start;
    justify-content:space-between;
    gap:16px;
    flex-wrap:wrap;
  }
  .riwayat-id-row{
    display:flex;
    align-items:center;
    gap:10px;
    flex-wrap:wrap;
  }
  .riwayat-id-row h3{
    font-family: var(--font-display);
    font-weight:800;
    font-size:15px;
    color: var(--ink);
  }
  .status-badge{
    font-size:10.5px;
    font-weight:700;
    letter-spacing:.02em;
    padding:5px 12px;
    border-radius: var(--radius-pill);
    white-space:nowrap;
  }
  .status-badge.progress{ background:#fdebd9; color: var(--orange-dark); }
  .status-badge.success{ background:#e8f3de; color:#4f7a35; }

  .riwayat-meta{
    font-size:12px;
    color: var(--ink-soft);
    margin-top:6px;
  }

  .riwayat-total{ text-align:right; }
  .riwayat-total .label{
    display:block;
    font-size:9.5px;
    letter-spacing:.05em;
    text-transform:uppercase;
    color: var(--ink-soft);
    margin-bottom:4px;
  }
  .riwayat-total .value{
    font-family: var(--font-display);
    font-weight:700;
    font-size:17px;
    color: var(--ink);
  }
  .riwayat-total .value.accent{ color: var(--orange-dark); }
  .riwayat-total .pay-status{
    display:block;
    font-size:11px;
    font-weight:600;
    margin-top:3px;
    color:#4f7a35;
  }
  .riwayat-total .pay-status.muted{ color: var(--ink-soft); }

  .riwayat-body{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:20px;
    flex-wrap:wrap;
    margin-top:20px;
    padding-top:20px;
    border-top:1px solid rgba(122,59,18,.08);
  }
  .riwayat-items p{
    font-size:12.5px;
    color: var(--ink);
    margin-bottom:4px;
  }
  .riwayat-items p:last-child{ margin-bottom:0; }
  .riwayat-items strong{ font-weight:700; }

  .riwayat-courier{
    background: var(--cream-soft);
    border-radius: 10px;
    padding:12px 16px;
    flex:none;
  }
  .riwayat-courier .name{
    font-size:12.5px;
    font-weight:700;
    color: var(--ink);
  }
  .riwayat-courier .detail{
    font-size:11px;
    color: var(--ink-soft);
    margin-top:2px;
  }

  .riwayat-footer{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:16px;
    flex-wrap:wrap;
    margin-top:20px;
    padding-top:20px;
    border-top:1px solid rgba(122,59,18,.08);
  }
  .riwayat-invoice-note{
    display:inline-flex;
    align-items:center;
    gap:6px;
    font-size:11.5px;
    color: var(--ink-soft);
  }
  .riwayat-invoice-note svg{ width:14px; height:14px; color:#5f9a3b; flex:none; }
  .riwayat-actions{
    display:flex;
    align-items:center;
    gap:10px;
    flex-wrap:wrap;
  }

  /* ---------- RESPONSIVE ---------- */
  @media (max-width: 980px){
    .account-grid{ grid-template-columns:1fr; }
    .billing-card{ flex-direction:column; align-items:flex-start; }
    .billing-cta{ text-align:left; }
  }
  @media (max-width: 560px){
    .riwayat-card{ padding:22px 18px; }
    .riwayat-total{ text-align:left; }
    .filter-bar{ flex-direction:column; align-items:stretch; }
    .filter-search{ justify-content:stretch; }
    .search-box{ max-width:none; }
  }
</style>
@endpush

@section('content')

  <section class="account-page reveal">
    <div class="container">
      <div class="account-grid">

        <!-- SIDEBAR -->
        <aside>
          <div class="profile-card">
            <div class="profile-avatar">
              <img src="{{ asset('images/profil-reva.jpg') }}" alt="Foto profil Reva Aulia A.">
            </div>
            <h2 class="profile-name">Reva Aulia A.</h2>
            <p class="profile-email">revanjai@email.com</p>
            <span class="profile-badge">Bergabung sejak Februari 2023</span>

            <div class="profile-stats">
              <div class="stat-box">
                <span class="stat-label">Total Pesanan</span>
                <span class="stat-value">38 Menu</span>
              </div>
              <div class="stat-box">
                <span class="stat-label">Hemat Kupon</span>
                <span class="stat-value accent">Rp 145rb</span>
              </div>
            </div>
          </div>

          <nav class="account-menu">
            <a href="/biodata" class="account-menu-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              Biodata Diri
            </a>
            <a href="/alamat" class="account-menu-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              Daftar Alamat
            </a>
            <a href="/riwayat" class="account-menu-item active">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="15" y2="17"/></svg>
              Riwayat &amp; Invoice
              <svg class="menu-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
            </a>
            <a href="/pengaturan" class="account-menu-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
              Pengaturan Akun
            </a>
            <a href="/logout" class="account-menu-item logout">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
              Keluar dari Akun
            </a>
          </nav>
        </aside>

        <!-- MAIN -->
        <div class="account-main">

          <!-- RINGKASAN TAGIHAN BULANAN -->
          <div class="billing-card">
            <div>
              <h1>Ringkasan Tagihan Bulanan</h1>
              <p>Semua pembayaran pesanan telah terverifikasi resmi untuk kebutuhan arsip pengeluaran pribadi maupun kantor.</p>
              <div class="billing-total-box">
                <span class="label">Total Transaksi</span>
                <span class="value">Rp 485.000</span>
              </div>
            </div>
            <div class="billing-cta">
              <a href="/invoice/rekap" class="btn-primary-sm">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Unduh Rekap Pajak &amp; Invoice
              </a>
              <p class="hint">Format PDF terintegrasi QRIS</p>
            </div>
          </div>

          <!-- FILTER & PENCARIAN -->
          <div class="filter-bar">
            <div class="filter-tabs">
              <button type="button" class="filter-tab active">Semua Pesanan (18)</button>
              <button type="button" class="filter-tab">Sedang Berjalan (1)</button>
              <button type="button" class="filter-tab">Selesai (16)</button>
              <button type="button" class="filter-tab">Dibatalkan (1)</button>
            </div>
            <div class="filter-search">
              <div class="search-box">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="text" placeholder="Cari ID Pesanan / Menu...">
              </div>
              <button type="button" class="icon-btn">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              </button>
            </div>
          </div>

          <!-- DAFTAR PESANAN -->

          <!-- Pesanan #1: Dalam Pengantaran -->
          <div class="riwayat-card highlight">
            <div class="riwayat-top">
              <div>
                <div class="riwayat-id-row">
                  <h3>#2DA-89211</h3>
                  <span class="status-badge progress">DALAM PENGANTARAN</span>
                </div>
                <p class="riwayat-meta">Hari ini, 11:20 WIB &bull; Tebet Barat Dalam VI (Rumah Tinggal)</p>
              </div>
              <div class="riwayat-total">
                <span class="label">Total Tagihan</span>
                <span class="value accent">Rp 25.000</span>
                <span class="pay-status">QRIS Lunas</span>
              </div>
            </div>

            <div class="riwayat-body">
              <div class="riwayat-items">
                <p><strong>2x Corndog Mini Mozarella</strong> (Saos Sambal &amp; Mayo Gurih)</p>
                <p><strong>1x Cireng Isi Mini</strong> (Bumbu Tabur Pedas)</p>
              </div>
              <div class="riwayat-courier">
                <p class="name">Kurir: Kang Rahmat</p>
                <p class="detail">Honda Vario &bull; Estimasi tiba 8 mnt lagi</p>
              </div>
            </div>

            <div class="riwayat-footer">
              <span class="riwayat-invoice-note">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg>
                No. Invoice: INV/20241018/2DA/89211
              </span>
              <div class="riwayat-actions">
                <a href="#" class="btn-outline-sm" data-modal-open="modalDetailPesanan">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-1"/><path d="M9 5a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2M9 5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2"/><line x1="9" y1="14" x2="15" y2="14"/><line x1="9" y1="18" x2="15" y2="18"/></svg>
                  Detail &amp; Invoice
                </a>
              </div>
            </div>
          </div>

          <!-- Pesanan #2: Selesai -->
          <div class="riwayat-card">
            <div class="riwayat-top">
              <div>
                <div class="riwayat-id-row">
                  <h3>#2DA-87104</h3>
                  <span class="status-badge success">SELESAI DINIKMATI</span>
                </div>
                <p class="riwayat-meta">Kemarin, 14:15 WIB &bull; Kantor Menara Karya (Studio)</p>
              </div>
              <div class="riwayat-total">
                <span class="label">Total Tagihan</span>
                <span class="value">Rp 35.000</span>
                <span class="pay-status">QRIS Lunas</span>
              </div>
            </div>

            <div class="riwayat-body">
              <div class="riwayat-items">
                <p><strong>2x Corndog Mini Mozarella</strong> (Saus Sambal)</p>
                <p><strong>1x Cireng Isi Mini + 2x Pop Ice Chocolate</strong></p>
              </div>
              <span class="link-review">
                <svg viewBox="0 0 20 20"><path d="M10 1l2.755 5.91L19 7.64l-4.5 4.386L15.51 18 10 14.911 4.49 18l1.01-5.973L1 7.64l6.245-.73z"/></svg>
                Sudah Dinilai: 5.0 (Sangat Lezat)
              </span>
            </div>

            <div class="riwayat-footer">
              <span class="riwayat-invoice-note">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg>
                Pesanan diterima resepsionis
              </span>
              <div class="riwayat-actions">
                <a href="/invoice/2DA-87104" class="btn-outline-sm">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                  Unduh Invoice (PDF)
                </a>
                <a href="/menulogin" class="btn-soft-sm">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
                  Pesan Lagi
                </a>
              </div>
            </div>
          </div>

          <!-- Pesanan #3: Selesai -->
          <div class="riwayat-card">
            <div class="riwayat-top">
              <div>
                <div class="riwayat-id-row">
                  <h3>#2DA-84920</h3>
                  <span class="status-badge success">SELESAI DINIKMATI</span>
                </div>
                <p class="riwayat-meta">12 Okt 2024, 19:30 WIB &bull; Tebet Barat Dalam VI</p>
              </div>
              <div class="riwayat-total">
                <span class="label">Total Tagihan</span>
                <span class="value">Rp 10.000</span>
                <span class="pay-status muted">COD Tunai Selesai</span>
              </div>
            </div>

            <div class="riwayat-body">
              <div class="riwayat-items">
                <p><strong>1x Corndog Mini Mozarella</strong> (Saus Mayo)</p>
                <p><strong>1x Ice Good Day Freeze</strong> (Extra Ice)</p>
              </div>
              <a href="/form-pesanan?pesanan=2DA-84920" class="link-review">
                <svg viewBox="0 0 20 20"><path d="M10 1l2.755 5.91L19 7.64l-4.5 4.386L15.51 18 10 14.911 4.49 18l1.01-5.973L1 7.64l6.245-.73z"/></svg>
                Beri Ulasan
              </a>
            </div>

            <div class="riwayat-footer">
              <span class="riwayat-invoice-note">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg>
                Invoice: INV/20241012/2DA/84920
              </span>
              <div class="riwayat-actions">
                <a href="/invoice/2DA-84920" class="btn-outline-sm">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                  Unduh Invoice (PDF)
                </a>
                <a href="/menulogin" class="btn-soft-sm">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
                  Pesan Lagi
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>

  @include('detail')

@endsection

@push('scripts')
@include('partials.cart-script')
<script>
  // Toggle style aktif untuk filter tab (tidak mengubah data, hanya UI state)
  document.querySelectorAll('.filter-tab').forEach(function (btn) {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.filter-tab').forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
    });
  });

  // Pesanan yang baru dibuat dari halaman pesanan tampil paling atas
  // (dibaca dari TwodaOrders; nanti diganti data dari database)
  (function renderNewOrders() {
    const orders = TwodaOrders.list();
    const firstCard = document.querySelector('.riwayat-card');
    if (!orders.length || !firstCard) return;

    const payLabel = {
      qris: 'QRIS &bull; Menunggu Verifikasi',
      va: 'Virtual Account &bull; Menunggu Pembayaran',
      cod: 'COD &bull; Bayar di Tempat'
    };
    const checkIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg>';
    function rupiah(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }
    function pad(n) { return String(n).padStart(2, '0'); }
    function esc(s) {
      return String(s).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    }

    orders.forEach(function (o, idx) {
      const d = new Date(o.createdAt);
      const sameDay = d.toDateString() === new Date().toDateString();
      const when = (sameDay ? 'Hari ini' : d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }))
        + ', ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ' WIB';
      const ymd = d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate());
      const addr = String(o.address || '');
      const addrShort = addr.length > 40 ? addr.slice(0, 40) + '…' : addr;
      const items = (o.items || []).filter(function (i) { return PRODUCTS[i.id]; }).map(function (i) {
        return '<p><strong>' + i.qty + 'x ' + esc(PRODUCTS[i.id].name) + '</strong></p>';
      }).join('');

      const card = document.createElement('div');
      card.className = 'riwayat-card' + (idx === 0 ? ' highlight' : '');
      card.innerHTML = `
        <div class="riwayat-top">
          <div>
            <div class="riwayat-id-row">
              <h3>#${esc(o.id)}</h3>
              <span class="status-badge progress">MENUNGGU KONFIRMASI</span>
            </div>
            <p class="riwayat-meta">${when} &bull; ${esc(addrShort)}</p>
          </div>
          <div class="riwayat-total">
            <span class="label">Total Tagihan</span>
            <span class="value accent">${rupiah(o.total)}</span>
            <span class="pay-status">${payLabel[o.payment] || ''}</span>
          </div>
        </div>
        <div class="riwayat-body">
          <div class="riwayat-items">${items}</div>
        </div>
        <div class="riwayat-footer">
          <span class="riwayat-invoice-note">
            ${checkIcon}
            No. Invoice: INV/${ymd}/2DA/${esc(String(o.id).replace('2DA-', ''))}
          </span>
        </div>`;
      firstCard.parentNode.insertBefore(card, firstCard);
    });
  })();
</script>
@endpush