@extends('layouts.app')

@section('title', '2DA Store — Testimoni')

@push('styles')
<style>
  /* ---------- PAGE HEAD (disamakan dengan hero halaman Menu) ---------- */
  .page-head{
    background: radial-gradient(circle at 50% 30%, #fbdcc4 0%, var(--cream) 70%);
    padding: 104px 0 74px;
  }
  .page-head .container{
    display:flex;
    flex-direction:column;
    align-items:center;
    text-align:center;
  }
  .page-head .breadcrumb{
    font-size:12px;
    font-weight:600;
    letter-spacing:.04em;
    text-transform:uppercase;
    color: #5a4335;
    margin-bottom:16px;
  }
  .page-head .breadcrumb a{ transition: color .2s ease; }
  .page-head .breadcrumb a:hover{ color: var(--brown-dark); }
  .page-head .breadcrumb .current{ color: #d9672c; }
  .page-head h1{
    font-family: var(--font-display);
    font-weight:800;
    font-size: clamp(32px, 4.2vw, 48px);
    color: #d9672c;
    margin-bottom:14px;
  }
  .page-head p{
    max-width:520px;
    margin:0 auto;
    color: #5a4335;
    font-size:14px;
  }

  /* ---------- TESTIMONIALS GRID ---------- */
  .section{ padding: 44px 0 100px; }

  /* .testi-grid & .testi-card dipakai juga oleh beranda dengan desain beda,
     jadi semua propertinya ditimpa penuh di sini (bukan cuma ditambah) */
  .testi-grid{
    display:grid;
    grid-template-columns: repeat(3, 1fr);
    gap:26px;
    margin-top: 0;
  }

  .testi-card{
    background: var(--white);
    border-radius: var(--radius-lg);
    padding: 26px;
    box-shadow: 0 10px 24px -16px rgba(60,30,10,.25);
    display: block;
    min-height: 0;
  }
  .testi-card:nth-child(2){ background: var(--white); }

  .testi-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin-bottom:16px;
  }

  .testi-who{
    display:flex;
    align-items:center;
    gap:12px;
  }

  /* .avatar juga dipakai beranda (ukuran & gradient beda), ditimpa penuh */
  .avatar{
    width:38px; height:38px;
    border-radius:50%;
    flex:none;
    display:flex; align-items:center; justify-content:center;
    color:#fff;
    font-family: var(--font-display);
    font-weight:700;
    font-size:13px;
  }

  .testi-name{
    font-family: var(--font-display);
    font-weight:700;
    font-size:15px;
    color: var(--orange-dark);
  }

  .stars{
    color: #E8A83D;
    font-size:13px;
    letter-spacing:2px;
    white-space:nowrap;
  }

  .testi-text{
    font-size:14.5px;
    color: var(--ink-soft);
    line-height:1.65;
    margin-bottom:18px;
  }

  .testi-photo{
    border-radius: 12px;
    overflow:hidden;
    aspect-ratio: 16/9;
    background:#eee;
  }
  .testi-photo img{
    width:100%; height:100%; object-fit:cover;
  }

  /* ---------- RESPONSIVE (khusus halaman ini) ---------- */
  @media (max-width: 980px){
    .testi-grid{ grid-template-columns: 1fr 1fr; }
  }
  @media (max-width: 560px){
    .page-head{ padding: 68px 0 48px; }
    .page-head h1{ font-size:30px; }
    .testi-grid{ grid-template-columns: 1fr; }
    .testi-card{ padding: 26px; }
  }
</style>
@endpush

@section('content')

  <section class="page-head reveal">
    <div class="container">
      <h1>Apa Kata Mereka?</h1>
      <p>Cerita asli dari pelanggan yang sudah mencicipi kelezatan camilan hangat 2DA Store.</p>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="testi-grid" id="testiGrid"></div>
    </div>
  </section>

@endsection

@push('scripts')
<script>
  // ---------- Data testimoni (terhubung dengan foto produk di public/images/) ----------
  const TESTIMONIALS = [
    {
      name: "Reva A.",
      initials: "RA",
      color: "#E8734A",
      rating: 5,
      text: "Corndog mozzarellanya beneran lumer pas digigit! Digoreng garing dan disajikan masih hangat, jadi camilan favorit kalau lagi nongkrong sore.",
      photo: "{{ asset('images/corndog.jpg') }}"
    },
    {
      name: "Qonita Z.",
      initials: "QZ",
      color: "#B85F16",
      rating: 5,
      text: "Cireng isi ayamnya juara, kenyal di luar tapi isiannya berasa banget. Pesan online juga gampang dan sampainya masih anget.",
      photo: "{{ asset('images/cireng.jpg') }}"
    },
    {
      name: "Sarah A.",
      initials: "SA",
      color: "#D97B29",
      rating: 5,
      text: "Pop Ice coklatnya creamy banget buat pelepas dahaga siang hari. Porsinya pas dan rasanya nggak eneg sama sekali.",
      photo: "{{ asset('images/coklat.jpg') }}"
    },
    {
      name: "Fanin K.",
      initials: "FK",
      color: "#7A3B12",
      rating: 5,
      text: "Roti maryamnya garing berlapis-lapis, apalagi ditaburi meses jadi manis gurih, pas banget buat cemilan sore.",
      photo: "{{ asset('images/maryam.jpg') }}"
    },
    {
      name: "Kayes M.",
      initials: "KM",
      color: "#C97A3D",
      rating: 5,
      text: "Tahu crispy-nya renyah di luar tapi lembut di dalam, bumbunya juga kerasa. Baru coba sekali langsung jadi langganan.",
      photo: "{{ asset('images/tahu.jpg') }}"
    },
    {
      name: "Najwa Rawr",
      initials: "NR",
      color: "#A85E24",
      rating: 5,
      text: "Tempura jontornya pedas gurih pas di lidah, sambal cocolannya juara. Recommended banget buat yang suka pedas!",
      photo: "{{ asset('images/tempura.jpg') }}"
    }
  ];

  const grid = document.getElementById('testiGrid');

  TESTIMONIALS.forEach(t => {
    const card = document.createElement('article');
    card.className = 'testi-card reveal';

    const starsHtml = '★'.repeat(t.rating) + '☆'.repeat(5 - t.rating);

    card.innerHTML = `
      <div class="testi-head">
        <div class="testi-who">
          <div class="avatar" style="background:${t.color}">${t.initials}</div>
          <span class="testi-name">${t.name}</span>
        </div>
        <span class="stars">${starsHtml}</span>
      </div>
      <p class="testi-text">${t.text}</p>
      <div class="testi-photo"><img src="${t.photo}" alt="Foto pesanan ${t.name}"></div>
    `;
    grid.appendChild(card);
    window.observeReveal(card);
  });
</script>
@endpush