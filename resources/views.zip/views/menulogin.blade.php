@extends('layouts.applogin')

@section('title', '2DA Store — Menu Spesial')

@push('styles')
<style>
  /* ---------- PAGE HEAD (disamakan dengan hero halaman Tentang Kami) ---------- */
  .page-head{
    background: radial-gradient(circle at 50% 30%, #fbdcc4 0%, var(--cream) 70%);
    padding: 76px 0 50px;
  }
  .page-head .container{
    display:flex;
    flex-direction:column;
    align-items:center;
    text-align:center;
  }
  .page-head .breadcrumb{
    font-size:12px;
    font-weight:600;
    letter-spacing:.04em;
    text-transform:uppercase;
    color: #5a4335;
    margin-bottom:16px;
  }
  .page-head .breadcrumb a{ transition: color .2s ease; }
  .page-head .breadcrumb a:hover{ color: var(--brown-dark); }
  .page-head .breadcrumb .current{ color: #d9672c; }
  .page-head .kicker{
    font-family: var(--font-display);
    font-weight:800;
    font-size: clamp(32px, 4.2vw, 48px);
    margin-bottom:14px;
    color: #d9672c;
  }
  .page-head .kicker .accent{ color: #d9672c; }
  .page-head p{
    max-width:520px;
    margin:0 auto;
    color: #5a4335;
    font-size:14px;
  }

  /* ---------- SEARCH & FILTER ---------- */
  .search-wrap{
    width:100%;
    max-width:640px;
    margin: 36px 0 0;
  }
  .search-wrap input{
    width:100%;
    padding: 17px 26px;
    border-radius: var(--radius-pill);
    border: none;
    font-family: inherit;
    font-size: 15px;
    outline:none;
    background:#fff;
    box-shadow: 0 8px 20px -10px rgba(60,30,10,.18);
  }
  .search-wrap input::placeholder{ color:#b9a99c; }

  .filters{
    display:flex;
    justify-content:center;
    width:100%;
    gap:14px;
    margin: 26px 0 10px;
    flex-wrap:wrap;
  }
  .filter-btn{
    background:#fff;
    color: var(--ink-soft);
    font-family:inherit;
    font-weight:600;
    font-size:14px;
    padding: 12px 26px;
    border-radius: var(--radius-pill);
    border:none;
    cursor:pointer;
    transition: all .2s ease;
  }
  .filter-btn.active{
    background: var(--orange);
    color:#fff;
  }
  .filter-btn:hover:not(.active){ background: var(--cream-soft); }

  /* ---------- MENU GRID ---------- */
  .section{ padding: 56px 0 100px; }

  .products-grid{
    display:grid;
    grid-template-columns: repeat(3, 1fr);
    gap:32px;
  }

  .product-card{
    background: var(--white);
    border-radius: var(--radius-lg);
    overflow:hidden;
    display:flex;
    flex-direction:column;
    box-shadow: 0 10px 24px -14px rgba(60,30,10,.25);
    transition: transform .18s ease, box-shadow .18s ease;
  }
  .product-card:hover{
    transform: translateY(-4px);
    box-shadow: 0 18px 32px -14px rgba(60,30,10,.32);
  }
  .product-card.hidden{ display:none; }

  .product-media{
    position:relative;
    overflow:hidden;
    height: 210px;
    width: 100%;
    aspect-ratio: auto;
    margin-bottom: 0;
    border-radius: 0;
    background: #eee;
  }
  .product-media img{
    width:100%; height:100%; object-fit:cover;
    transition: transform .5s ease;
  }
  .product-card:hover .product-media img{ transform: scale(1.06); }

  .tag{
    position:absolute;
    top:16px; left:16px;
    background: var(--orange);
    color:#fff;
    font-size:11px;
    font-weight:700;
    letter-spacing:.04em;
    padding:6px 14px;
    border-radius: var(--radius-pill);
    text-transform:uppercase;
  }

  .product-body{
    padding: 22px 24px 26px;
    display:flex;
    flex-direction:column;
    flex:1;
  }

  .product-body h3{
    font-family: var(--font-display);
    font-weight:700;
    font-size:19px;
    color: var(--ink);
    line-height:1.3;
    margin-bottom:8px;
    display:-webkit-box;
    -webkit-line-clamp:2;
    -webkit-box-orient:vertical;
    overflow:hidden;
    min-height: calc(19px * 1.3 * 2);
  }

  .product-card .desc{
    font-size:14px;
    color: var(--ink-soft);
    line-height:1.6;
    display:-webkit-box;
    -webkit-line-clamp:3;
    -webkit-box-orient:vertical;
    overflow:hidden;
    min-height: calc(14px * 1.6 * 3);
  }

  .product-footer{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    margin-top:auto;
    padding-top:18px;
  }

  .price{
    font-family: var(--font-display);
    font-weight:700;
    font-size:17px;
    color: var(--orange-dark);
    white-space:nowrap;
  }

  .btn-add{
    background: var(--brown);
    color:#fff;
    font-family:inherit;
    font-weight:600;
    font-size:13px;
    padding: 12px 20px;
    border-radius: var(--radius-pill);
    white-space:nowrap;
    transition: background .2s ease, transform .1s ease;
  }
  .btn-add:hover{ background: var(--brown-dark); }
  .btn-add:active{ transform: scale(0.96); }
  .btn-add.added{ background: var(--orange-dark); }

  .no-results{
    grid-column: 1 / -1;
    text-align:center;
    padding: 60px 20px;
    color: var(--ink-soft);
    display:none;
  }
  .no-results.show{ display:block; }

  /* ---------- TOAST ---------- */
  .toast{
    position:fixed;
    bottom:30px; left:50%;
    transform: translateX(-50%) translateY(20px);
    background: var(--brown-dark);
    color:#fff;
    padding: 14px 26px;
    border-radius: var(--radius-pill);
    font-size:14px;
    font-weight:500;
    opacity:0;
    pointer-events:none;
    transition: opacity .25s ease, transform .25s ease;
    z-index:999;
    box-shadow: 0 12px 26px -8px rgba(0,0,0,.4);
  }
  .toast.show{
    opacity:1;
    transform: translateX(-50%) translateY(0);
  }

  /* ---------- RESPONSIVE (khusus halaman ini) ---------- */
  @media (max-width: 980px){
    .products-grid{ grid-template-columns:1fr 1fr; }
  }
  @media (max-width: 560px){
    .page-head{ padding: 56px 0 36px; }
    .page-head .kicker{ font-size:30px; }
    .products-grid{ grid-template-columns:1fr; }
    .section{ padding: 40px 0 70px; }
  }
</style>
@endpush

@section('content')

  <section class="page-head reveal">
    <div class="container">
      <h1 class="kicker">Menu 2DA Store</h1>
      <p>Nikmati pilihan camilan hangat dan lezat kami, dibuat dengan bahan premium untuk menemani momen spesial Anda setiap hari.</p>

      <div class="search-wrap">
        <input type="text" id="searchInput" placeholder="Cari camilan favoritmu...">
      </div>

      <div class="filters">
        <button class="filter-btn active" data-filter="semua">Semua</button>
        <button class="filter-btn" data-filter="makanan">Makanan</button>
        <button class="filter-btn" data-filter="minuman">Minuman</button>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="products-grid" id="menuGrid">

        <article class="product-card reveal" data-category="makanan" data-name="corndog mini mozzarella">
          <a href="/produklogin?id=corndog" class="product-link"><div class="product-media">
            <span class="tag">Best Seller</span>
            <img src="{{ asset('images/corndog.jpg') }}" alt="Corndog Mini Mozzarella">
          </div></a>
          <div class="product-body">
            <h3><a href="/produklogin?id=corndog" class="title-link">Corndog Mini Mozzarella</a></h3>
            <p class="desc">Sensasi renyah di luar dengan keju mozzarella premium yang meleleh sempurna di dalam dan disajikan hangat.</p>
            <div class="product-footer">
              <span class="price">Rp 5.000</span>
              <button class="btn-add">Tambah ke Keranjang</button>
            </div>
          </div>
        </article>

        <article class="product-card reveal" data-category="makanan" data-name="cireng isi mini">
          <a href="/produklogin?id=cireng" class="product-link"><div class="product-media">
            <img src="{{ asset('images/cireng.jpg') }}" alt="Cireng Isi Mini">
          </div></a>
          <div class="product-body">
            <h3><a href="/produklogin?id=cireng" class="title-link">Cireng Isi Mini</a></h3>
            <p class="desc">Cireng yang digoreng renyah diluar lembut didalam dengan nikmatnya isian ayam suwir yang lembut.</p>
            <div class="product-footer">
              <span class="price">Rp 5.000</span>
              <button class="btn-add">Tambah ke Keranjang</button>
            </div>
          </div>
        </article>
 
        <article class="product-card reveal" data-category="minuman" data-name="pop ice coklat">
          <a href="/produklogin?id=coklat" class="product-link"><div class="product-media">
            <img src="{{ asset('images/coklat.jpg') }}" alt="Pop Ice Coklat">
          </div></a>
          <div class="product-body">
            <h3><a href="/produklogin?id=coklat" class="title-link">Pop Ice Coklat</a></h3>
            <p class="desc">Minuman es dari bubuk rasa coklat yang di blender, creamy dan menyegarkan pas dinikmati saat cuaca panas.</p>
            <div class="product-footer">
              <span class="price">Rp 5.000</span>
              <button class="btn-add">Tambah ke Keranjang</button>
            </div>
          </div>
        </article>

        <article class="product-card reveal" data-category="makanan" data-name="roti maryam mini">
          <a href="/produklogin?id=maryam" class="product-link"><div class="product-media">
            <img src="{{ asset('images/maryam.jpg') }}" alt="Roti Maryam Mini">
          </div></a>
          <div class="product-body">
            <h3><a href="/produklogin?id=maryam" class="title-link">Roti Maryam Mini</a></h3>
            <p class="desc">Roti lapis khas Timur Tengah yang digoreng garing berlapis-lapis, disajikan hangat dengan taburan meses di atasnya.</p>
            <div class="product-footer">
              <span class="price">Rp 5.000</span>
              <button class="btn-add">Tambah ke Keranjang</button>
            </div>
          </div>
        </article>
 
        <article class="product-card reveal" data-category="makanan" data-name="tahu crispy">
          <a href="/produklogin?id=tahu" class="product-link"><div class="product-media">
            <span class="tag">Baru</span>
            <img src="{{ asset('images/tahu.jpg') }}" alt="Tahu Crispy">
          </div></a>
          <div class="product-body">
            <h3><a href="/produklogin?id=tahu" class="title-link">Tahu Crispy</a></h3>
            <p class="desc">Tahu digoreng dengan balutan tepung berbumbu, menghasilkan tekstur renyah di luar dan lembut gurih di dalam.</p>
            <div class="product-footer">
              <span class="price">Rp 5.000</span>
              <button class="btn-add">Tambah ke Keranjang</button>
            </div>
          </div>
        </article>
 
        <article class="product-card reveal" data-category="makanan" data-name="tempura jontor">
          <a href="/produklogin?id=tempura" class="product-link"><div class="product-media">
            <img src="{{ asset('images/tempura.jpg') }}" alt="Tempura Jontor">
          </div></a>
          <div class="product-body">
            <h3><a href="/produklogin?id=tempura" class="title-link">Tempura Jontor</a></h3>
            <p class="desc">Potongan tempura ayam berbumbu gurih, digoreng garing dan disajikan dengan sambal pedas manis.</p>
            <div class="product-footer">
              <span class="price">Rp 5.000</span>
              <button class="btn-add">Tambah ke Keranjang</button>
            </div>
          </div>
        </article>

        <p class="no-results" id="noResults">Camilan yang kamu cari tidak ditemukan. Coba kata kunci lain.</p>

      </div>
    </div>
  </section>

  <div class="toast" id="toast">Item ditambahkan ke keranjang</div>

@endsection

@push('scripts')
<script>
  // Pencarian & filter kategori
  const searchInput = document.getElementById('searchInput');
  const filterBtns = document.querySelectorAll('.filter-btn');
  const cards = document.querySelectorAll('.product-card');
  const noResults = document.getElementById('noResults');
  const toast = document.getElementById('toast');

  let activeFilter = 'semua';

  function applyFilters(){
    const query = searchInput.value.trim().toLowerCase();
    let visibleCount = 0;

    cards.forEach(card => {
      const category = card.dataset.category;
      const name = card.dataset.name;
      const matchesCategory = activeFilter === 'semua' || category === activeFilter;
      const matchesSearch = name.includes(query);

      if(matchesCategory && matchesSearch){
        card.classList.remove('hidden');
        visibleCount++;
      } else {
        card.classList.add('hidden');
      }
    });

    noResults.classList.toggle('show', visibleCount === 0);
  }

  searchInput.addEventListener('input', applyFilters);

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeFilter = btn.dataset.filter;
      applyFilters();
    });
  });

  // Tambah ke keranjang
  let cartCount = 0;
  document.querySelectorAll('.btn-add').forEach(btn => {
    btn.addEventListener('click', () => {
      cartCount++;
      const itemName = btn.closest('.product-card').querySelector('h3').textContent;
      toast.textContent = `${itemName} ditambahkan ke keranjang (${cartCount})`;
      toast.classList.add('show');
      btn.classList.add('added');
      setTimeout(() => btn.classList.remove('added'), 400);
      clearTimeout(window._toastTimer);
      window._toastTimer = setTimeout(() => toast.classList.remove('show'), 2000);
    });
  });
</script>
@endpush