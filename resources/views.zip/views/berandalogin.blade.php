@extends('layouts.applogin')

@section('content')

  <!-- HERO -->
  <section class="hero" id="beranda">
    <div class="container hero-inner">
      <div class="hero-copy reveal">
        <h1>Nikmati Jajanan Favorit di 2DA Store!</h1>
        <p>Nikmati kelezatan Corndog mozzarella, Cireng renyah, dan aneka camilan hangat lainnya. Dibuat fresh setiap hari untuk menemani waktu santai Anda.</p>
        <div class="hero-actions">
          <button class="btn btn-primary" id="pesanBtn">Pesan Sekarang</button>
          <a href="/menulogin" class="btn btn-outline">Jelajahi Menu</a>
        </div>
      </div>
    </div>
  </section>

  <!-- PRODUCTS -->
  <section class="section" id="menu">
    <div class="container">
      <div class="section-head reveal">
        <h2 class="kicker"><span class="accent">Produk</span> Pilihan Kami</h2>
        <p>Kurasi terbaik dari alam, disiapkan dengan penuh cinta untuk menyempurnakan hari Anda.</p>
      </div>

      <div class="products-grid">
        <article class="product-card reveal">
          <div class="product-media">
            <img src="{{ asset('images/cireng.jpg') }}" alt="Cireng isi mini">
          </div>
          <div class="product-row">
            <h3>Cireng Isi Mini</h3>
            <span class="price">Rp 5.000</span>
          </div>
          <p class="desc">Cireng isi ayam suwir</p>
        </article>

        <article class="product-card reveal">
          <div class="product-media">
            <span class="tag">Terlaris</span>
            <img src="{{ asset('images/corndog.jpg') }}" alt="Corndog Mini Mozzarella">
          </div>
          <div class="product-row">
            <h3>Corndog Mini Mozarella</h3>
            <span class="price">Rp 5.000</span>
          </div>
          <p class="desc">Corndog isi mozarella</p>
        </article>

        <article class="product-card reveal">
          <div class="product-media">
            <img src="{{ asset('images/maryam.jpg') }}" alt="Roti maryam mini">
          </div>
          <div class="product-row">
            <h3>Roti Maryam Mini</h3>
            <span class="price">Rp 5.000</span>
          </div>
          <p class="desc">Roti maryam ukuran mini</p>
        </article>
      </div>

      <div class="section-cta reveal">
        <a href="/menulogin" class="link-cta">Lihat Koleksi Lengkap →</a>
      </div>
    </div>
  </section>

  <!-- QUALITY -->
  <section class="quality" id="cara-pesan">
    <div class="container">
      <div class="quality-inner reveal">
        <h2><span class="accent">Kualitas</span> <span class="dark">yang Berbicara</span></h2>
        <p>Di 2DA Store, kami percaya bahwa camilan terbaik adalah yang disajikan hangat dan fresh. Kami menggunakan resep autentik dan bahan pilihan untuk memastikan setiap gigitan memberikan kepuasan maksimal.</p>
        <p>Dari dapur kami langsung ke tangan Anda, komitmen kami pada rasa dan kualitas tidak pernah berubah. Nikmati kelezatan jajanan populer dengan standar premium.</p>
        <a href="/tentanglogin" class="cta-link">Pelajari Kisah Kami</a>
      </div>
    </div>
  </section>

  <!-- TESTIMONIALS -->
  <section class="testimonials" id="testimoni">
    <div class="container">
      <div class="section-head reveal">
        <h2 class="kicker">Testimoni</h2>
        <p>Pengalaman nyata dari pelanggan setia kami.</p>
      </div>

      <div class="testi-grid">
        <div class="testi-card reveal">
          <blockquote>"Corndog mozarellanya juara! Kejunya lumer banget dan selalu disajikan hangat, jadi favorit ngemil sore saya sama teman-teman kantor."</blockquote>
          <div class="testi-author">
            <div class="avatar"></div>
            <div>
              <div class="name">Budi Santoso</div>
              <div class="role">Pelanggan Setia</div>
            </div>
          </div>
        </div>

        <div class="testi-card reveal">
          <blockquote>"Cireng isi ayamnya bikin nagih, renyah di luar tapi lembut di dalam. Pesan online juga gampang dan pengirimannya cepat sampai masih hangat."</blockquote>
          <div class="testi-author">
            <div class="avatar"></div>
            <div>
              <div class="name">Siti Rahma</div>
              <div class="role">Pecinta jajanan Gurih</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

@endsection

@push('scripts')
<script>

  // Simple CTA feedback
  document.getElementById('pesanBtn').addEventListener('click', () => {
    document.querySelector('#menu').scrollIntoView({ behavior: 'smooth' });
  });
</script>
@endpush