{{--
  partials/cart-script.blade.php
  Katalog produk + helper keranjang/pesanan untuk sisi frontend (disimpan di localStorage browser).

  Di-include lewat @push('scripts') di: produk, produklogin, keranjang, pesanan, riwayat.
  Catatan: ini penyimpanan sementara sampai backend (route/controller/database) siap.
  Setelah backend jadi, cukup ganti isi TwodaCart / TwodaOrders dengan request ke server;
  halaman-halamannya tidak perlu diubah lagi.
--}}
<script>
  // ---------- DATA PRODUK (terhubung dengan menu lewat ?id=) ----------
  const PRODUCTS = {
    corndog: {
      name: "Corndog Mini Mozzarella",
      price: 5000,
      short: "Corndog molor keju mozarella",
      label: "Terlaris",
      image: "{{ asset('images/corndog.jpg') }}",
      desc: [
        "Corndog Mini Mozarella kami menghadirkan sensasi gigitan renyah di luar dan lumer di dalam. Balutan tepung crispy yang digoreng garing membungkus keju mozarella premium yang meleleh sempurna di setiap suapan, disiram saus sambal dan mayones khas yang bikin nagih.",
        "Dibuat fresh setiap hari dengan bahan pilihan, corndog mini ini pas banget jadi camilan sore, teman nongkrong, atau bekal ngemil kapan aja. Praktis disantap langsung dari tusuknya, cocok buat semua usia — dari anak-anak sampai dewasa."
      ],
      ingredients: ["Digoreng garing setiap kali pesanan masuk", "Keju mozzarella premium lumer sempurna", "Porsi mini pas untuk sekali gigitan", "Praktis disantap langsung dari tusuknya"]
    },
    cireng: {
      name: "Cireng Isi Mini",
      price: 5000,
      short: "Cireng isi mini, kenyal & gurih",
      image: "{{ asset('images/cireng.jpg') }}",
      desc: [
        "Cireng Isi Mini punya tekstur kenyal khas cireng di luar dengan isian gurih yang melimpah di dalam — mulai dari ayam suwir pedas sampai keju yang lumer, siap memanjakan lidah di setiap gigitan. Digoreng garing sampai warnanya kuning keemasan, disajikan hangat dengan cocolan sambal favoritmu.",
        "Ukuran mini yang pas buat ngemil santai, cocok dinikmati rame-rame bareng teman atau keluarga. Jajanan sejuta umat ini selalu jadi andalan buat menemani waktu senggangmu."
      ],
      ingredients: ["Kenyal di luar, isian melimpah di dalam", "Digoreng garing hingga keemasan", "Disajikan hangat dengan cocolan sambal", "Ukuran mini, pas dinikmati rame-rame"]
    },
    coklat: {
      name: "Pop Ice Coklat",
      price: 5000,
      short: "Pop ice rasa coklat",
      image: "{{ asset('images/coklat.jpg') }}",
      desc: [
        "Pop Ice jadi minuman segar andalan buat menemani harimu, hadir dengan berbagai varian rasa manis dan menyegarkan yang siap melepas dahaga. Diseduh dan disajikan dingin dengan tekstur creamy yang bikin nagih setiap tegukan.",
        "Cocok diminum siang hari saat cuaca terik atau sebagai teman santai sore-sore. Kesegarannya bikin mood langsung membaik!"
      ],
      ingredients: ["Rasa coklat creamy dan menyegarkan", "Disajikan dingin, pas untuk cuaca panas", "Porsi pas, tidak bikin eneg", "Cepat saji, langsung siap diminum"]
    },
    maryam: {
      name: "Roti Maryam Mini",
      price: 5000,
      short: "Roti maryam ukuran mini",
      image: "{{ asset('images/maryam.jpg') }}",
      desc: [
        "Roti Maryam Mini punya lapisan yang berlapis-lapis, renyah di luar dan lembut di dalam, dengan aroma mentega yang menggoda. Disajikan hangat bersama taburan gula atau siraman kuah kari/coklat sesuai selera, menciptakan perpaduan rasa manis gurih yang bikin ketagihan.",
        "Ukuran mininya pas buat ngemil ringan atau dinikmati beramai-ramai. Enak disantap kapan aja — pagi buat sarapan, sore buat teman ngeteh, atau malam buat cemilan santai."
      ],
      ingredients: ["Berlapis-lapis, renyah di luar lembut di dalam", "Aroma mentega yang menggoda", "Bisa dinikmati manis maupun gurih", "Cocok untuk sarapan, ngeteh, atau cemilan malam"]
    },
    tahu: {
      name: "Tahu Crispy",
      price: 5000,
      short: "Tahu crispy renyah & gurih",
      image: "{{ asset('images/tahu.jpg') }}",
      desc: [
        "Tahu Crispy kami digoreng dengan balutan tepung renyah yang garing sempurna, membungkus tahu lembut nan gurih di dalamnya. Perpaduan tekstur crunchy di luar dan lembut di dalam ini bikin susah berhenti ngemil.",
        "Disajikan dengan sambal kecap atau saus sambal sesuai selera, tahu crispy ini pas jadi camilan sore atau pelengkap makan siangmu. Praktis, mengenyangkan, dan pastinya bikin nagih."
      ],
      ingredients: ["Renyah di luar, lembut gurih di dalam", "Bumbu meresap sempurna ke dalam tahu", "Cocok jadi camilan atau pelengkap makan", "Porsi mengenyangkan, harga terjangkau"]
    },
    tempura: {
      name: "Tempura Jontor",
      price: 5000,
      short: "Tempura pedas level nampol",
      image: "{{ asset('images/tempura.jpg') }}",
      desc: [
        "Tempura Jontor hadir dengan level pedas yang bikin nagih — gurihnya tempura ikan yang kenyal berpadu dengan saus pedas nampol yang bikin bibir jontor tapi tetap ketagihan buat nambah lagi. Cocok buat kamu pecinta pedas sejati!",
        "Disajikan hangat dengan tusukan praktis, tempura jontor ini jadi teman ngemil paling asik saat kumpul bareng teman. Siap-siap keringetan tapi susah berhenti!"
      ],
      ingredients: ["Level pedas nampol yang bikin nagih", "Tekstur kenyal khas tempura ikan", "Disajikan hangat dengan tusukan praktis", "Favorit para pecinta pedas sejati"]
    }
  };

  // ---------- KERANJANG ----------
  // Format simpan: [{ id: 'corndog', qty: 2 }, ...]   (harga/nama diambil dari PRODUCTS)
  const TwodaCart = (function () {
    const CART_KEY = 'twoda_cart_v1';
    const CHECKOUT_KEY = 'twoda_checkout_v1';   // id produk yang dicentang di halaman keranjang

    function load(key) {
      try {
        const raw = localStorage.getItem(key);
        const data = raw ? JSON.parse(raw) : [];
        if (!Array.isArray(data)) return [];
        return data.filter(function (i) {
          return i && PRODUCTS[i.id] && Number.isInteger(i.qty) && i.qty > 0;
        });
      } catch (e) { return []; }
    }
    function save(key, items) {
      try { localStorage.setItem(key, JSON.stringify(items)); } catch (e) {}
    }

    return {
      items: function () { return load(CART_KEY); },
      count: function () {
        return load(CART_KEY).reduce(function (n, i) { return n + i.qty; }, 0);
      },
      add: function (id, qty) {
        if (!PRODUCTS[id]) return;
        const items = load(CART_KEY);
        const found = items.find(function (i) { return i.id === id; });
        if (found) { found.qty += qty; } else { items.push({ id: id, qty: qty }); }
        save(CART_KEY, items);
      },
      setQty: function (id, qty) {
        const items = load(CART_KEY);
        const found = items.find(function (i) { return i.id === id; });
        if (!found) return;
        found.qty = Math.max(1, qty);
        save(CART_KEY, items);
      },
      remove: function (id) {
        save(CART_KEY, load(CART_KEY).filter(function (i) { return i.id !== id; }));
      },
      removeMany: function (ids) {
        save(CART_KEY, load(CART_KEY).filter(function (i) { return ids.indexOf(i.id) === -1; }));
      },
      // pilihan checkout: hanya menyimpan id; jumlahnya selalu dibaca dari keranjang
      setCheckout: function (ids) { save(CHECKOUT_KEY, ids.map(function (id) { return { id: id, qty: 1 }; })); },
      checkoutItems: function () {
        const cart = load(CART_KEY);
        const chosen = load(CHECKOUT_KEY).map(function (i) { return i.id; });
        if (!chosen.length) return cart;                       // belum pilih apa-apa -> semua isi keranjang
        return cart.filter(function (i) { return chosen.indexOf(i.id) !== -1; });
      },
      clearCheckout: function () {
        try { localStorage.removeItem(CHECKOUT_KEY); } catch (e) {}
      }
    };
  })();

  // ---------- RIWAYAT PESANAN ----------
  const TwodaOrders = (function () {
    const KEY = 'twoda_orders_v1';
    function load() {
      try {
        const raw = localStorage.getItem(KEY);
        const data = raw ? JSON.parse(raw) : [];
        return Array.isArray(data) ? data : [];
      } catch (e) { return []; }
    }
    return {
      list: function () { return load(); },            // terbaru di paling atas
      add: function (order) {
        const all = load();
        all.unshift(order);
        try { localStorage.setItem(KEY, JSON.stringify(all)); } catch (e) {}
      }
    };
  })();
</script>
