<footer>
  <div class="container footer-grid">
    <div class="footer-brand">
      <h3>2DA Store</h3>
      <p>Menyajikan jajanan jalanan yang lezat, hangat, dan siap menemani hari-harimu. Kepuasan perutmu adalah prioritas kami.</p>
      <div class="socials">
      <a href="https://www.instagram.com/revvaaau?stkn=MWc1Y2t6cTg2ZGsydA==" aria-label="Instagram" target="_blank">
        <img src="{{ asset('images/ig.png') }}" alt="Instagram">
      </a>
      <a href="#" aria-label="TikTok" target="_blank">
        <img src="{{ asset('images/tiktok.png') }}" alt="TikTok">
      </a>
      <a href="https://wa.me/qr/2P5AZ55NI6WOP1" aria-label="WhatsApp" target="_blank">
        <img src="{{ asset('images/wa.png') }}" alt="WhatsApp">
      </a>
    </div>
    </div>
    <div>
      <h4>Tautan Cepat</h4>
      <ul class="footer-links">
        <li><a href="/menu">Menu Kami</a></li>
        <li><a href="/cara-pesan">Cara Pesan</a></li>
        <li><a href="/testimoni">Testimoni</a></li>
      </ul>
    </div>
    <div>
      <h4>Informasi</h4>
      <ul class="footer-links">
        <li><a href="/tentang">Tentang Kami</a></li>
        <li><a href="/hubungi">Hubungi Kami</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">© 2026 2DA Store.</div>
</footer>